import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import pygame
pygame.init()

def even(n): return (n % 2) == 0

global WIDTH,HEIGHT,CLOCK,RGB,ASSETS,SIZE,WINSIZE,SET,OFFSET,HOLDING

RGB = {
	"white":(255,255,255),
	"black":(0,0,0),
	"red":(255,0,0),
	"green":(0,255,0),
	"blue":(0,0,255),
	"yellow":(255,255,0),
	"cyan":(0,255,255),
	"magenta":(255,0,255)
}
SIZE = 80
WINSIZE = SIZE*8
WIDTH,HEIGHT = WINSIZE,WINSIZE
CLOCK = pygame.time.Clock()
FPS = 60
OFFSET = 20
HOLDING = (False,None)
# SET = [[None for j in range(HEIGHT//SIZE)] for i in range(WIDTH//SIZE)]
SET = [
	list("rnbqkbnr"),
	list("pppppppp"),
	[None, None, None, None, None, None, None, None],
	[None, None, None, None, None, None, None, None],
	[None, None, None, None, None, None, None, None],
	[None, None, None, None, None, None, None, None],
	list("PPPPPPPP"),
	list("RNBQKBNR")
]

ASSETS = {
	"icon": pygame.image.load("./assets/pieces/w/king.png"),
	"font": pygame.font.SysFont("Courier New",32,bold=True),
	"pieces":{
		"k" :pygame.transform.scale(pygame.image.load("./assets/pieces/b/king.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"q" :pygame.transform.scale(pygame.image.load("./assets/pieces/b/queen.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"n" :pygame.transform.scale(pygame.image.load("./assets/pieces/b/knight.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"b" :pygame.transform.scale(pygame.image.load("./assets/pieces/b/bishop.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"p" :pygame.transform.scale(pygame.image.load("./assets/pieces/b/pawn.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"r" :pygame.transform.scale(pygame.image.load("./assets/pieces/b/rook.png"),(SIZE-OFFSET,SIZE-OFFSET)),

		"K" :pygame.transform.scale(pygame.image.load("./assets/pieces/w/king.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"Q" :pygame.transform.scale(pygame.image.load("./assets/pieces/w/queen.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"N" :pygame.transform.scale(pygame.image.load("./assets/pieces/w/knight.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"B" :pygame.transform.scale(pygame.image.load("./assets/pieces/w/bishop.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"P" :pygame.transform.scale(pygame.image.load("./assets/pieces/w/pawn.png"),(SIZE-OFFSET,SIZE-OFFSET)),
		"R" :pygame.transform.scale(pygame.image.load("./assets/pieces/w/rook.png"),(SIZE-OFFSET,SIZE-OFFSET)),
	},
	# "sound":{
	#	"spark": pygame.mixer.Sound("./assets/spark.wav"),
	#	"win": pygame.mixer.Sound("./assets/win.wav"),
	#	"switch": pygame.mixer.Sound("./assets/switch.wav"),
	#	"deswitch": pygame.mixer.Sound("./assets/deswitch.wav"),
	# }
}

def board(win):
	for i,elist in enumerate(SET):
		for j,ele in enumerate(elist):
			win.rect(pygame.Rect(j*SIZE,i*SIZE,SIZE,SIZE),RGB["white"] if even(j+i) else RGB["black"])
			if ele != None:
				win.blit(ASSETS["pieces"][str(ele)],((j*SIZE)+(OFFSET//2),(i*SIZE)+(OFFSET//2)))

def main(win,events):
	global HOLDING
	pos = pygame.mouse.get_pos()
	for event in events:
		if event.type == pygame.MOUSEBUTTONUP:# and event.button == 3:
			# if ((pos[0] < 0) or (pos[0] > WIDTH)) or ((pos[1] < 0) or (pos[1] > HEIGHT)):
			if not HOLDING[0]:
				t = SET[pos[1]//SIZE][pos[0]//SIZE]
				if t == None:
					continue
				HOLDING = True,t
				SET[pos[1]//SIZE][pos[0]//SIZE] = None
			elif HOLDING[0]:
				SET[pos[1]//SIZE][pos[0]//SIZE] = HOLDING[1]
				HOLDING = False,None
	if HOLDING[0]:
		win.blit(ASSETS["pieces"][str(HOLDING[1])],((pos[0])-((SIZE-OFFSET)//2),(pos[1])-((SIZE-OFFSET)//2)))



class Window():
	def __init__(self,title,width,height):
		self.width,self.height,self.title = width,height,title
		self.obj = pygame.display.set_mode((self.width,self.height))
		pygame.display.set_caption(title)
		pygame.display.set_icon(ASSETS["icon"])
		self.fill,self.blit,self.rect = self.obj.fill,self.obj.blit,lambda value,color:pygame.draw.rect(self.obj, color, value)
	def update(self):
		return pygame.display.update()

run = True
win = Window("Chess",width=WIDTH,height=HEIGHT)
while run:
	CLOCK.tick(FPS)
	events = pygame.event.get()
	keys = pygame.key.get_pressed()
	for event in events:
		if event.type == pygame.QUIT:
			run = False
	board(win)
	main(win,events)
	win.update()
pygame.quit()